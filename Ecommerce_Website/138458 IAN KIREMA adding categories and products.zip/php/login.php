<html>
    <head>
        <title>LOGIN</title>

        <link rel="stylesheet" href="../css/style.css"> 
    </head>
    <body class="bodylogin">
        
        <form method="" action="">
           <div style="position: absolute; left:450px; top: 20px;">
            <h1>PRIME DESIGNERS <span>Login</span></h1>
            <fieldset class="fieldset1">
               

                     <li><label for="mail">Email :</label>
                     <input type="email" id="mail" name="E_mail"></li><br>

                     <li><label for="pword">Password :</label>
                     <input type="password" id="pword" name="pass_word"></li><br>

                     <li><input type="SUBMIT" id="login"></li><br>

                     <p>Don't have an account? <a href="register.html">SignUp here</a>.</p>
					  <a href="index.html">HOME</a>

    
                
            </fieldset>
            </div>
        </form>
        
    </body>
</html>