<html>
    <head>
        <title>ADMIN LOGIN</title>

        <link rel="stylesheet" href="../css/style.css"> 
    </head>
    <body class="adminlogin">
        
        <form method="" action="">
           <div style="position: absolute; left:450px; top: 20px;">
            <h1>PRIME DESIGNERS <span>ADMINLogin</span></h1>
            <fieldset class="fieldset1">
               

                     <li><label for="mail">Email :</label>
                     <input type="email" id="mail" name="E_mail"></li><br>

                     <li><label for="pword">Password :</label>
                     <input type="password" id="pword" name="pass_word"></li><br>

                     <p>ADMIN ONLY : <a href="categories.html"><br><br><input type="SUBMIT" id="login"></a></p>
					  <a href="index.html">HOME</a>
  
            </fieldset>
            </div>
        </form>
        
    </body>
</html>